from django.contrib import admin
from .models import *

admin.site.register(RideStatus)
admin.site.register(Rides)
admin.site.register(Role)
admin.site.register(Vehicle)
admin.site.register(SharerRequest)