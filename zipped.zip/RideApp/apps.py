from django.apps import AppConfig


class RideappConfig(AppConfig):
    name = 'RideApp'
